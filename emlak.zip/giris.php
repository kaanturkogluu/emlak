<?php
// Admin login sayfasına yönlendir
header('Location: admin/login.php');
exit;
?>
