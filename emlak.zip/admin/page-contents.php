<?php
session_start();
require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../classes/Database.php';
require_once __DIR__ . '/../classes/AdminUser.php';
require_once __DIR__ . '/../classes/Helper.php';

$adminUser = new AdminUser();
if (!$adminUser->isLoggedIn()) {
    header('Location: login.php');
    exit;
}

$helper = Helper::getInstance();
$db = Database::getInstance()->getConnection();

$pageTitle = "Sayfa İçerikleri Yönetimi";

$success = '';
$error = '';

// Sayfa içeriklerini güncelle
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $pageType = $_POST['page_type'] ?? '';
    $sectionType = $_POST['section_type'] ?? '';
    $title = $_POST['title'] ?? '';
    $subtitle = $_POST['subtitle'] ?? '';
    $content = $_POST['content'] ?? '';
    $imageUrl = $_POST['image_url'] ?? '';
    
    if (!empty($pageType) && !empty($sectionType)) {
        try {
            // Sayfa içeriğini güncelle veya ekle
            $stmt = $db->prepare("
                INSERT INTO page_contents (page_type, section_type, title, subtitle, content, image_url, updated_at) 
                VALUES (?, ?, ?, ?, ?, ?, NOW()) 
                ON DUPLICATE KEY UPDATE 
                title = VALUES(title),
                subtitle = VALUES(subtitle),
                content = VALUES(content),
                image_url = VALUES(image_url),
                updated_at = VALUES(updated_at)
            ");
            $stmt->execute([$pageType, $sectionType, $title, $subtitle, $content, $imageUrl]);
            $success = 'Sayfa içeriği başarıyla güncellendi!';
        } catch (Exception $e) {
            $error = 'Sayfa içeriği güncellenirken bir hata oluştu: ' . $e->getMessage();
        }
    } else {
        $error = 'Lütfen gerekli alanları doldurun!';
    }
}

// Sayfa içeriklerini al
$pageContents = [];
$pageTypes = [
    'hakkimizda' => 'Hakkımızda'
];

$sectionTypes = [
    'hero' => 'Başlık Alanı',
    'main_content' => 'İçerik Alanı',
    'mission' => 'Misyonumuz',
    'vision' => 'Vizyonumuz',
    'values' => 'Değerlerimiz',
    'team' => 'Ekibimiz'
];

foreach ($pageTypes as $type => $name) {
    $stmt = $db->prepare("SELECT section_type, title, subtitle, content, image_url FROM page_contents WHERE page_type = ? ORDER BY 
        CASE section_type 
            WHEN 'hero' THEN 1
            WHEN 'main_content' THEN 2
            WHEN 'mission' THEN 3
            WHEN 'vision' THEN 4
            WHEN 'values' THEN 5
            WHEN 'team' THEN 6
            ELSE 7
        END");
    $stmt->execute([$type]);
    $sections = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    $pageContents[$type] = [];
    foreach ($sections as $section) {
        $pageContents[$type][$section['section_type']] = $section;
    }
}

require_once __DIR__ . '/layout/header.php';
?>

<div class="content-wrapper">
    <div class="action-bar">
        <h3><i class="fas fa-file-alt"></i> Sayfa İçerikleri Yönetimi</h3>
        <p>Site sayfalarının içeriklerini düzenleyebilirsiniz.</p>
    </div>

    <?php if ($success): ?>
        <div class="alert alert-success">
            <i class="fas fa-check-circle"></i>
            <?php echo $success; ?>
        </div>
    <?php endif; ?>
    
    <?php if ($error): ?>
        <div class="alert alert-error">
            <i class="fas fa-exclamation-circle"></i>
            <?php echo $error; ?>
        </div>
    <?php endif; ?>

    <div class="page-contents-grid">
        <?php foreach ($pageTypes as $type => $name): ?>
            <div class="page-content-card">
                <div class="page-content-header">
                    <h4><?php echo $name; ?></h4>
                </div>
                <div class="page-sections">
                    <?php foreach ($sectionTypes as $sectionType => $sectionName): ?>
                        <div class="section-item">
                            <div class="section-header">
                                <h5><?php echo $sectionName; ?></h5>
                                <button class="btn btn-primary btn-sm" onclick="editPageSection('<?php echo $type; ?>', '<?php echo $sectionType; ?>', '<?php echo $sectionName; ?>')">
                                    <i class="fas fa-edit"></i> Düzenle
                                </button>
                            </div>
                            <div class="section-preview">
                                <?php if (isset($pageContents[$type][$sectionType])): ?>
                                    <?php $section = $pageContents[$type][$sectionType]; ?>
                                    <?php if (!empty($section['title'])): ?>
                                        <p><strong>Başlık:</strong> <?php echo $helper->e($section['title']); ?></p>
                                    <?php endif; ?>
                                    <?php if (!empty($section['subtitle'])): ?>
                                        <p><strong>Alt Başlık:</strong> <?php echo $helper->e(substr($section['subtitle'], 0, 100)) . '...'; ?></p>
                                    <?php endif; ?>
                                    <?php if (!empty($section['content'])): ?>
                                        <p><strong>İçerik:</strong> <?php echo $helper->e(substr(strip_tags($section['content']), 0, 100)) . '...'; ?></p>
                                    <?php endif; ?>
                                    <?php if (!empty($section['image_url'])): ?>
                                        <p><strong>Resim:</strong> <?php echo $helper->e($section['image_url']); ?></p>
                                    <?php endif; ?>
                                <?php else: ?>
                                    <p class="text-muted">Henüz içerik eklenmemiş.</p>
                                <?php endif; ?>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>
        <?php endforeach; ?>
    </div>
</div>

<!-- Düzenleme Modal -->
<div class="modal" id="editModal">
    <div class="modal-content">
        <div class="modal-header">
            <h3 id="modalTitle">Sayfa İçeriği Düzenle</h3>
            <button class="modal-close" onclick="closeModal()">&times;</button>
        </div>
        <form method="POST" action="">
            <div class="modal-body">
                <input type="hidden" id="pageType" name="page_type" value="">
                <input type="hidden" id="sectionType" name="section_type" value="">
                
                <div class="form-group">
                    <label for="title">Başlık:</label>
                    <input type="text" id="title" name="title" class="form-control" placeholder="Bölüm başlığını girin...">
                </div>
                
                <div class="form-group">
                    <label for="subtitle">Alt Başlık:</label>
                    <input type="text" id="subtitle" name="subtitle" class="form-control" placeholder="Alt başlığı girin...">
                </div>
                
                <div class="form-group">
                    <label for="content">İçerik:</label>
                    <textarea id="content" name="content" rows="10" class="form-control" placeholder="İçeriği buraya yazın..."></textarea>
                </div>
                
                <div class="form-group">
                    <label for="imageUrl">Resim URL:</label>
                    <input type="url" id="imageUrl" name="image_url" class="form-control" placeholder="Resim URL'sini girin...">
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" onclick="closeModal()">İptal</button>
                <button type="submit" class="btn btn-primary">Kaydet</button>
            </div>
        </form>
    </div>
</div>

<style>
.content-wrapper {
    padding: 20px;
    max-width: 1200px;
    margin: 0 auto;
}

.action-bar {
    background: #fff;
    padding: 30px;
    border-radius: 10px;
    box-shadow: 0 2px 10px rgba(0,0,0,0.1);
    margin-bottom: 30px;
}

.action-bar h3 {
    margin: 0 0 10px 0;
    color: #2c3e50;
    font-size: 24px;
}

.action-bar p {
    margin: 0;
    color: #7f8c8d;
    font-size: 16px;
}

.action-bar h3 i {
    color: #3498db;
    margin-right: 10px;
}

.alert {
    padding: 15px 20px;
    border-radius: 8px;
    margin-bottom: 20px;
    display: flex;
    align-items: center;
}

.alert-success {
    background: #d4edda;
    color: #155724;
    border: 1px solid #c3e6cb;
}

.alert-error {
    background: #f8d7da;
    color: #721c24;
    border: 1px solid #f5c6cb;
}

.alert i {
    margin-right: 10px;
    font-size: 18px;
}

.page-contents-grid {
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(350px, 1fr));
    gap: 25px;
}

.page-content-card {
    background: #fff;
    border-radius: 12px;
    box-shadow: 0 4px 15px rgba(0,0,0,0.1);
    overflow: hidden;
    transition: all 0.3s ease;
    margin-bottom: 20px;
}

.page-content-card:hover {
    transform: translateY(-5px);
    box-shadow: 0 8px 25px rgba(0,0,0,0.15);
}

.page-content-header {
    padding: 20px;
    border-bottom: 2px solid #3498db;
    margin-bottom: 20px;
}

.page-content-header h4 {
    margin: 0;
    color: #2c3e50;
    font-size: 1.5rem;
}

.page-sections {
    padding: 0 20px 20px;
    display: grid;
    gap: 15px;
}

.section-item {
    background: #f8f9fa;
    border-radius: 8px;
    padding: 15px;
    border: 1px solid #e9ecef;
}

.section-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 10px;
}

.section-header h5 {
    margin: 0;
    color: #495057;
    font-size: 1.1rem;
}

.section-preview {
    color: #666;
    line-height: 1.6;
    font-size: 0.9rem;
}

.section-preview p {
    margin: 5px 0;
    color: #555;
    line-height: 1.6;
}

.text-muted {
    color: #95a5a6 !important;
    font-style: italic;
}

/* Modal Styles */
.modal {
    display: none;
    position: fixed;
    z-index: 1000;
    left: 0;
    top: 0;
    width: 100%;
    height: 100%;
    background-color: rgba(0,0,0,0.5);
}

.modal-content {
    background-color: #fff;
    margin: 5% auto;
    border-radius: 10px;
    width: 90%;
    max-width: 800px;
    max-height: 90vh;
    overflow-y: auto;
    box-shadow: 0 10px 30px rgba(0,0,0,0.3);
}

.modal-header {
    padding: 20px 30px;
    border-bottom: 1px solid #ecf0f1;
    display: flex;
    justify-content: space-between;
    align-items: center;
}

.modal-header h3 {
    margin: 0;
    color: #2c3e50;
}

.modal-close {
    background: none;
    border: none;
    font-size: 24px;
    cursor: pointer;
    color: #95a5a6;
    padding: 0;
    width: 30px;
    height: 30px;
    display: flex;
    align-items: center;
    justify-content: center;
}

.modal-close:hover {
    color: #e74c3c;
}

.modal-body {
    padding: 30px;
}

.modal-footer {
    padding: 20px 30px;
    border-top: 1px solid #ecf0f1;
    display: flex;
    justify-content: flex-end;
    gap: 10px;
}

.form-group {
    margin-bottom: 20px;
}

.form-group label {
    display: block;
    margin-bottom: 8px;
    color: #2c3e50;
    font-weight: 600;
}

.form-control {
    width: 100%;
    padding: 12px;
    border: 1px solid #ddd;
    border-radius: 6px;
    font-size: 14px;
    font-family: inherit;
    resize: vertical;
}

.form-control:focus {
    outline: none;
    border-color: #3498db;
    box-shadow: 0 0 0 2px rgba(52, 152, 219, 0.2);
}

.btn {
    padding: 10px 20px;
    border: none;
    border-radius: 6px;
    font-size: 14px;
    font-weight: 600;
    cursor: pointer;
    transition: all 0.3s ease;
    text-decoration: none;
    display: inline-flex;
    align-items: center;
    gap: 8px;
}

.btn-primary {
    background: #3498db;
    color: white;
}

.btn-primary:hover {
    background: #2980b9;
    transform: translateY(-2px);
}

.btn-secondary {
    background: #95a5a6;
    color: white;
}

.btn-secondary:hover {
    background: #7f8c8d;
}

.btn-sm {
    padding: 8px 16px;
    font-size: 12px;
}

/* Mobile Responsive */
@media (max-width: 768px) {
    .content-wrapper {
        padding: 10px;
    }
    
    .action-bar {
        padding: 20px;
    }
    
    .action-bar h3 {
        font-size: 20px;
    }
    
    .page-contents-grid {
        grid-template-columns: 1fr;
        gap: 20px;
    }
    
    .page-content-header {
        flex-direction: column;
        gap: 15px;
        align-items: flex-start;
    }
    
    .modal-content {
        width: 95%;
        margin: 10% auto;
    }
    
    .modal-header,
    .modal-body,
    .modal-footer {
        padding: 20px;
    }
    
    .modal-footer {
        flex-direction: column;
    }
    
    .btn {
        width: 100%;
        justify-content: center;
    }
}
</style>

<script>
function editPageSection(pageType, sectionType, sectionName) {
    document.getElementById('modalTitle').textContent = sectionName + ' Düzenle';
    document.getElementById('pageType').value = pageType;
    document.getElementById('sectionType').value = sectionType;
    
    // Mevcut içeriği yükle
    fetch('get-page-content.php?type=' + pageType + '&section=' + sectionType)
        .then(response => response.json())
        .then(data => {
            document.getElementById('title').value = data.title || '';
            document.getElementById('subtitle').value = data.subtitle || '';
            document.getElementById('content').value = data.content || '';
            document.getElementById('imageUrl').value = data.image_url || '';
        })
        .catch(error => {
            console.error('Error:', error);
            document.getElementById('title').value = '';
            document.getElementById('subtitle').value = '';
            document.getElementById('content').value = '';
            document.getElementById('imageUrl').value = '';
        });
    
    document.getElementById('editModal').style.display = 'block';
}

function closeModal() {
    document.getElementById('editModal').style.display = 'none';
}

// Modal dışına tıklandığında kapat
window.onclick = function(event) {
    const modal = document.getElementById('editModal');
    if (event.target === modal) {
        closeModal();
    }
}
</script>

<?php require_once __DIR__ . '/layout/footer.php'; ?>
