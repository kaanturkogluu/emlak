<?php

// Veritabanı Ayarları
define('DB_HOST', 'localhost');
define('DB_NAME', 'emlak');
define('DB_USER', 'root');
define('DB_PASS', '');

// Site Ayarları
define('BASE_URL', 'http://localhost/emlak');
define('SITE_NAME', 'Emlak Sitesi');

define('DEBUG', 'false');

define('TIMEZONE', 'Europe/Istanbul');

// Timezone ayarla
date_default_timezone_set(TIMEZONE);


//



// Veritabanı Ayarları
// define('DB_HOST', 'localhost');
// define('DB_NAME', 'u111121823_emlak');
// define('DB_USER', 'u111121823_emlak');
// define('DB_PASS', '@pWJJpE5');

// // Site Ayarları
// define('BASE_URL', 'http://raquun.net/');
// define('SITE_NAME', 'Emlak Sitesi');


// define('TIMEZONE', 'Europe/Istanbul');

// // Timezone ayarla
// date_default_timezone_set(TIMEZONE);
?>


